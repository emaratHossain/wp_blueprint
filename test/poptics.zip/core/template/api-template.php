<?php

namespace Poptics\Core\Template;

use Poptics\Base\Api;
use Poptics\Utils\Singleton;
use WP_HTTP_Response;

/**
 * Class API Campaign
 *
 * @since 1.0.0
 *
 * @package Poptics
 */
class Api_Template extends Api {

    use Singleton;

    /**
     * Store namespace
     *
     * @since 1.0.0
     *
     * @var string
     */
    protected $namespace = 'poptics/v1';

    /**
     * Store rest base
     *
     * @since 1.0.0
     *
     * @var string
     */
    protected $rest_base = 'remote';

    /**
     * Store rest base
     *
     * @since 1.0.0
     *
     * @var string
     */
    protected $data = [];

    /**
     * Store rest base
     *
     * @since 1.0.0
     *
     * @var string
     */
    protected $id = '';

    /**
     * Store cache group name
     *
     * @since 1.0.0
     *
     * @var string
     */
    protected $cache_group = 'poptics_template_api';

    /**
     * Register rest routes.
     *
     * @since 1.0.0
     *
     * @return  void
     */
    public function register_routes() {
        /**
         * Register popup-templates category list API
         */
        register_rest_route( $this->namespace, $this->rest_base . '/categories', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'template_categories'],
                'permission_callback' => function () {
                    return current_user_can( 'manage_options' );
                },
            ],
        ] );

        /**
         * Register popup-templates API
         */
        register_rest_route( $this->namespace, $this->rest_base . '/templates', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'templates'],
                'permission_callback' => function () {
                    return current_user_can( 'manage_options' );
                },
            ],
        ] );
    }

    /**
     * Fetch template categories
     *
     * @since 1.0.0
     *
     * @return \WP_REST_Response
     */
    public function template_categories() {
        $cache_key   = 'poptics_categories_data';
        $cached_data = get_transient( $cache_key );

        if ( !$cached_data ) {
            $response = wp_remote_get( 'https://demo.aethonic.com/poptics/wp-json/poptics/v1/categories' );
            if ( is_wp_error( $response ) ) {
                if ( is_wp_error( $response ) ) {
                    $response = [
                        'success'     => 0,
                        'status_code' => 500,
                        'message'     => esc_html__( 'Unable to fetch template categories', 'poptics' ),
                        'data'        => [],
                    ];

                    return rest_ensure_response( $response, 500 );
                }
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            set_transient( $cache_key, $data, 86400 );
        } else {
            $data = $cached_data;
        }

        return rest_ensure_response( $data, 200 );
    }

    /**
     * Retrieve templates from Aethonic demo site.
     *
     * Retrieves templates from Aethonic demo site and cache them for 10 seconds.
     * If the transient is not set or is expired, it will call the Aethonic demo site
     * to fetch the templates.
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */
    public function templates( $request ) {
        $response = poptics_verify_nonce( $request->get_header( 'x_wp_nonce' ) );
        if ( $response instanceof WP_HTTP_Response ) {
            return $response;
        }

        $cache_key   = 'poptics_templates_data';
        $cached_data = get_transient( $cache_key );

        if ( !$cached_data ) {
            $url      = 'https://demo.aethonic.com/poptics/wp-json/poptics/v1/templates';
            $response = wp_remote_get( $url );

            if ( is_wp_error( $response ) ) {
                if ( is_wp_error( $response ) ) {
                    $response = [
                        'success'     => 0,
                        'status_code' => 500,
                        'message'     => esc_html__( 'Unable to fetch template categories', 'poptics' ),
                        'data'        => [],
                    ];

                    return rest_ensure_response( $response, 500 );
                }
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            set_transient( $cache_key, $data, 86400 );
        } else {
            $data = $cached_data;
        }

        return rest_ensure_response( $data, 200 );
    }
}