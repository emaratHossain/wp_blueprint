=== Poptics - Popup Builder for Lead Generation, Conversions, and Forms for Email Options ===
Contributors: aethonic,abrasel600
Tags: popup, popups, popup builder, pop up, popup maker
Requires at least: 5.6
Tested up to: 6.6
Requires PHP: 7.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create high-converting popups, options, and lead generation forms for increased conversions, email subscribers, and sales for your website with the Poptics WordPress popup builder plugin.

== Description ==

Poptics is a [customizable popup builder plugin for WordPress](https://aethonic.com/poptics/) designed to increase leads and sales for your website.

Want to create responsive popups that convert instantly? Check this [Quick Guide](https://docs.aethonic.com/docs/getting-started/intro/quick-start-guide/)!

[Support](https://aethonic.com/support/) | [Documentation](https://docs.aethonic.com/docs/getting-started/) | [Buy Pro](https://aethonic.com/poptics/)

### Powerful WordPress Popup Builder to Increase Conversions

Create easy-to-use and interactive popup forms to grow your email list and revenue with conversion-focused campaigns with the Poptics WordPress popup plugin.

Effectively capture leads, get email subscribers, announce promotions, collect feedback, display targeted messages, reduce bounce rates, and CTAs across your website with a popup.

Poptics popup builder is simple and easy to use with a user-friendly and intuitive interface. No special coding is needed to use the plugin to create efficient and powerful WordPress popups.

### What do you get with Poptics?

✅ Abandonment Cart Reminder Popups
✅ Lightbox Popups
✅ Multi-Steps Popups
✅ Sticky bar Popups
✅ Sidebar Popups
✅ Slide-in Popups
✅ Fullscreen Popups
✅ Countdown Timers
✅ Contact form Builder
✅ Exit-intent Technology
✅ Page Level Targeting
✅ Popup Scheduling
✅ Auto Responder Email
✅ Loco Translate Support
✅ Floating Bar
✅ Mobile-responsive Design

Check out the [Roadmap](https://aethonic.com/poptics-roadmap/) for more!

### Create Multiple Popup Triggers

Create unlimited WordPress popups that detect visitor behavior to display the right campaign at the right time. Poptics popup triggers are specific actions or events that prompt a popup to appear so that you can **convert website exiting users** into customers.

✅ **Exit-Intent Popups** - Appear when a visitor's cursor moves toward the browser's exit button, aiming to retain them before they leave.
✅ **Time-Based Popups** - Triggered after a visitor has spent a specific amount of time on a page, encouraging engagement based on browsing duration.
✅ **Click-Triggered Popups** - Activate when a visitor clicks on a specific element, such as a button or link, prompting them with relevant content or offers.

### Generate More Leads Super Fast

Lead generation is now simpler with easy-to-set-up opt-in forms, targeted marketing popups, and professionally designed templates for different use cases. This way, with the Poptics WordPress popup plugin you can **grow your mailing list and convert subscribers to leads**.

Strategically display popups encouraging visitors to subscribe to email newsletters or take advantage of special offers. The smart targeting options allow you to customize messages based on user behavior, ensuring that every popup is relevant and effective. 

### Target the Right Visitors to Increase Sales

Boost your revenue with the Poptics WordPress popup plugin. Poptics popup maker plugin helps in lead collection and generation and significantly contributes to increasing sales to grow your business through marketing strategies.

A well-timed popup can prompt users to complete a purchase on cart items, sign up for a limited-time offer to make rapid purchases, or even follow social media accounts and increase social engagement and interactions. Additionally, Poptics popup maker offers analytics tools that help you **track engagement levels and optimize your campaigns** accordingly for popups.

### Create and Customize Popup Campaigns

With Poptics popup builder, you can choose from pre-built professional templates or design campaigns from scratch, adding form fields, images, and brand-specific elements. **Personalize your campaigns** with custom colors, fonts, and layout options to match your website’s style, ensuring your message grabs the attention of visitors for maximum engagement.

You can create the following campaigns with Poptics 👉

* [Lightbox Campaign](https://docs.aethonic.com/docs/getting-started/campaign-types/how-to-create-a-lightbox-popup-campaign/) - Lightbox popups are a fantastic, attention-grabbing way to turn your website visitors into subscribers or leads. With Poptics popup builder, you can easily create stunning lightbox popups that help drive conversions.

* [Fullscreen Campaign](https://docs.aethonic.com/docs/getting-started/campaign-types/how-to-create-a-fullscreen-campaign/) - Enables immersive fullscreen popups as fullscreen welcome mats to capture attention, boost engagement, and drive conversions effectively on your website with Poptics popup maker.

* [Sidebar Campaign](https://docs.aethonic.com/docs/getting-started/campaign-types/how-to-create-a-sidebar-campaign-in-wordpress/) - Utilize sidebar popups to engage visitors, promote offers, and capture leads without disrupting the browsing experience with Poptics popup builder.

* [Multisteps Campaign](https://docs.aethonic.com/docs/getting-started/campaign-types/how-to-create-multisteps-campaign/) - Feature interactive multistep popups that guide users through a series of prompts, enhancing engagement and lead capture effectively with Poptics popup maker.

* Phone Call Campaign - Allows to generate leads by enabling users to call your business directly from popups. Set up call-to-action buttons for easy customer access, enhancing lead conversion opportunities with Poptics popup builder.

### Create Customizable Forms

The drag-and-drop form builder is integrated into the Poptics WordPress popup plugin with the **Gutenberg block editor** to [create customizable forms](https://docs.aethonic.com/docs/getting-started/creating-from/how-to-create-subscriber-form/). Build personalized forms that can be displayed as popups on your website to match the brand’s style, message, and design preferences. Poptics also provides advanced images, headings, and button blocks.

You can configure it to send emails directly to your inbox or integrate with third-party services. This allows you to automate email marketing and sync form data with numerous external platforms.

An [auto-response email](https://docs.aethonic.com/docs/getting-started/creating-from/how-to-configure-auto-responder-email/) is an automatic email sent to users with Poptics popup builder after they engage with campaigns, like filling out an opt-in form or signing up for a newsletter. Automate leads nurturing acknowledges their action, provides additional information, or thanks them, all without manual effort.

### Available Integrations

✅ [FluentCRM](https://docs.aethonic.com/docs/getting-started/integrations/how-to-integrate-fluentcrm/)
✅ [Pabbly](https://docs.aethonic.com/docs/getting-started/integrations/how-to-integrate-pabbly/)
✅ [Zapier](https://docs.aethonic.com/docs/getting-started/integrations/how-to-integrate-zapier/)
✅ ActiveCampaign
✅ MailChimp

### Targeted Display Controls for Popups

Poptics popup builder display control strategies can **maximize engagement** with your audience. Manage your popups from a single dashboard 👉

* [Popup Placement Settings](https://docs.aethonic.com/docs/getting-started/display-controls/how-to-set-your-popup-placement/) - The Placement section lets you choose where to display your pop ups—on specific pages, posts, products, or throughout your entire website.
* [Audience and Targeting Settings](https://docs.aethonic.com/docs/getting-started/display-controls/how-to-set-audience-and-targeting/) - This lets you define who sees your pop ups by segmenting visitors based on visit history, location, and device type for maximum impact.
* [Popup Visibility Settings](https://docs.aethonic.com/docs/getting-started/display-controls/how-to-set-popup-visibility/) - Allows you to control how and when your popup appears to visitors, giving you the flexibility to engage users at the perfect moment.
* [Popup Frequency Settings](https://docs.aethonic.com/docs/getting-started/display-controls/how-to-set-popup-frequency/) - This lets you control how often pop ups appear based on visitor behavior, creating a non-intrusive experience while ensuring your campaign receives attention.
* [Campaign Schedule Settings](https://docs.aethonic.com/docs/getting-started/display-controls/how-to-set-campaign-schedule/) - Scheduling pop ups for specific times is a smart way to boost engagement. Poptics offers flexible scheduling options to simplify this process.

### Advanced Campaign and Conversion Analytics

The [Poptics Campaign Analytics](https://docs.aethonic.com/docs/getting-started/analytics-results/) report provides a detailed overview of the performance of your campaigns at both the site and campaign levels. It allows you to track key metrics and data to identify trends that help optimize your popups for better conversions.

✅ **Filters** - Filter the report by specific campaigns to analyze individual performance and select a custom date range to review results for a designated time period.
✅ **Key Metrics** - View unique visitors, number of views, number of conversions, and the percentage of visitors who converted on your pop up campaigns.
✅ **Statistics** - A visual chart displays the relationship between pop up impressions and conversions over time, providing insights into your campaign's performance.
✅ **Devices** - Shows your campaign performance across desktop, mobile, and tablet devices, helping you understand which ones your visitors use most.
✅ **Top Countries** - Displays the countries with the most traffic to your pop up campaign, helping you optimize for regional audiences.
✅ **Top Pages** - Highlights the best-performing pages for your popups, enabling you to refine targeting and focus on high-traffic areas.
✅ **Top Browsers** - A breakdown of the browsers used by visitors, providing insights into browser-specific issues or trends.

### Created by Aethonic

Poptics WordPress popup plugin is built by the [Aethonic](https://aethonic.com/) team. We develop premium WordPress plugins designed to improve the capabilities of your WordPress websites.

Check out some of our most popular plugins 👉

[Eventin](https://wordpress.org/plugins/wp-event-solution/) - Event management plugin for WordPress that simplifies event creation, ticketing, and registration processes.
[WPCafe](https://wordpress.org/plugins/wp-cafe/) - Restaurant management plugin for WordPress that enables online ordering, menu customization, and reservation management.
[WP Timetics](https://wordpress.org/plugins/timetics/) - A scheduling and booking plugin for WordPress that simplifies business appointment management.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/poptics` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to the *Poptics* menu on the WordPress dashboard to start creating your first popup.

== Frequently Asked Questions ==

= Can I use Poptics to capture leads and send them to my CRM? =
Yes, Poptics popup maker integrates with popular CRMs like FluentCRM, Pabbly, and ActiveCampaign. You can easily sync your form submissions with these platforms to automate lead management.

= Does Poptics work with Zapier? =
Absolutely! With Zapier integration, Poptics popup builder can connect to over 5,000 apps, allowing you to automate workflows and sync data across your marketing tools.

= Can I customize the design of my popup forms? =
Yes! Poptics WordPress popup plugin allows full customization of the popup design, including text, colors, layout, and animations, ensuring that your popups match your website's branding.

= What kind of popups can I create? =
You can create various types of popups such as exit-intent popups, timed popups, click-triggered popups, and more.

== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3

== Changelog ==

= 1.0.1 =
New: All the custom post made dynamic in campaign page target control section
New: Tags and categories are also available in campaign page target control section
New: Custom Poptics Image Box block created
New: Provide animation settings for popup body
New: Advanced settings for Poptics Button block implemented
New: Custom Input Blocks made editable with advance menu
New: Provide a status toggle button in campaign list table
New: Poptics wooCommerce block created to insert products in popups
Fix: Template design broken issue fixed
Fix: Form submission and validation off in edit mode
Fix: Countdown selected value not showing issue
Tweak: Move the device switch button from center to left
Tweak: Submission filter loading added
Tweak: Setup webhook for poptics onboarding

= 1.0.0 =
* Initial release of Poptics.

== Upgrade Notice ==


== License ==

This plugin is licensed under the GPLv2 or later. See the license file for more details.
