<?php

namespace Poptics\Base;

/**
 * Admin class
 *
 * @since 1.0.0
 *
 * @package Poptics
 */
class Admin {
    use \Poptics\Utils\Singleton;

    /**
     * Initialize the class
     *
     * @since 1.0.0
     *
     * @return  void
     */
    public function init() {
        add_action( 'admin_enqueue_scripts', [$this, 'enqueue_scripts'], 10 );
    }

    /**
     * Enqueue scripts and styles
     *
     * @since 1.0.0
     *
     * @return  void
     */
    public function enqueue_scripts() {
        wp_enqueue_media();
        wp_enqueue_script( 'wp-edit-post' );
        wp_enqueue_script( 'poptics-script' );
        wp_enqueue_script( 'poptics-packages' );
        wp_enqueue_script( 'poptics-guten-block' );
        wp_set_script_translations( 'poptics-script', 'poptics' );
        wp_enqueue_style( 'poptics-style' );

        $page_list = apply_filters( 'poptics_get_cpt_wise_dynamic_posts', get_all_post_types_with_posts() );

        $category_list = poptics_all_post_categories();
        $tag_list      = poptics_all_post_tags();

        $page_list = array_merge( $page_list, $category_list, $tag_list );

        $localize_obj = array(
            'site_url'        => site_url(),
            'admin_url'       => admin_url(),
            'nonce'           => wp_create_nonce( 'wp_rest' ),
            'post_categories' => poptics_all_post_categories(),
            'post_tags'       => poptics_all_post_tags(),
            'page_lists'      => $page_list,
        );

        $localize_obj = apply_filters( 'poptics_admin_localize_data', $localize_obj );

        wp_localize_script( 'poptics-script', 'poptics', $localize_obj );

        $settings = poptics_editor_settings();
        wp_add_inline_script( 'poptics-script', 'window.popticsEditorSettings = ' . wp_json_encode( $settings ) . ';' );
    }
}